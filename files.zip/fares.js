// ============================================================
//  /api/fares  — Main fare endpoint
//  Fires all sources in parallel, merges best result per app
// ============================================================
const express      = require('express');
const router       = express.Router();
const { getRoute } = require('../utils/googleMaps');
const { getCache, setCache } = require('../utils/cache');
const { scrapeUber }  = require('../scrapers/uber');
const { scrapeBolt }  = require('../scrapers/bolt');
const { scrapeOla }   = require('../scrapers/ola');
const { calcAllFares }= require('../formula/calculator');
const { log, warn }   = require('../utils/logger');
const crypto          = require('crypto');

// ── POST /api/fares ──────────────────────────────────────────
router.post('/fares', async (req, res) => {
  const { pickup, dropoff, country, city } = req.body;

  // ── Input validation ────────────────────────────────────
  if (!pickup?.lat || !pickup?.lng || !dropoff?.lat || !dropoff?.lng) {
    return res.status(400).json({
      error: 'Missing required fields: pickup.lat, pickup.lng, dropoff.lat, dropoff.lng'
    });
  }
  if (!country || !city) {
    return res.status(400).json({ error: 'Missing required fields: country, city' });
  }

  const p  = { lat: parseFloat(pickup.lat),  lng: parseFloat(pickup.lng) };
  const d  = { lat: parseFloat(dropoff.lat), lng: parseFloat(dropoff.lng) };
  const cc = country.toUpperCase(); // 'TH', 'SG', 'IN' etc.

  // ── Cache check ─────────────────────────────────────────
  const cacheKey = `fares:${p.lat.toFixed(3)},${p.lng.toFixed(3)}:${d.lat.toFixed(3)},${d.lng.toFixed(3)}:${cc}:${city}`;
  const cached = await getCache(cacheKey);
  if (cached) {
    log(`Cache HIT for ${city} route`);
    return res.json({ ...cached, cached: true });
  }

  try {
    // ── Step 1: Get route distance + duration from Google Maps ──
    log(`Fetching route: ${city} (${cc})`);
    const route = await getRoute(p.lat, p.lng, d.lat, d.lng);

    // ── Step 2: Fire all sources in PARALLEL ────────────────
    log(`Running all fare sources in parallel...`);
    const [uberResult, boltResult, olaResult, formulaResult] = await Promise.allSettled([
      scrapeUber(p, d, cc),
      scrapeBolt(p, d, cc, city),
      cc === 'IN' ? scrapeOla(p, d) : Promise.resolve(null), // Ola only for India
      calcAllFares(route.distanceKm, route.durationMin, cc, city),
    ]);

    // ── Step 3: Merge — best source wins per app ─────────────
    const fares = mergeFares({
      scrape: {
        uber: safeValue(uberResult),
        bolt: safeValue(boltResult),
        ola:  safeValue(olaResult),
      },
      formula: safeValue(formulaResult),
    });

    if (!fares || fares.length === 0) {
      warn('All sources failed — returning error');
      return res.status(503).json({ error: 'Could not fetch fares — please retry' });
    }

    // ── Step 4: Attach route info to response ────────────────
    const response = {
      fares,
      route: {
        distanceKm:  route.distanceKm,
        durationMin: route.durationMin,
        durationText: route.durationText,
        distanceText: route.distanceText,
      },
      city,
      country: cc,
      fetchedAt: new Date().toISOString(),
    };

    // ── Step 5: Cache for 5 minutes ─────────────────────────
    await setCache(cacheKey, response, 300);

    log(`Returning ${fares.length} fare entries for ${city}`);
    return res.json(response);

  } catch (err) {
    warn(`Unhandled error in /api/fares: ${err.message}`);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ── Helper: safely extract value from Promise.allSettled result ──
function safeValue(result) {
  if (result.status === 'fulfilled' && result.value) return result.value;
  if (result.status === 'rejected') warn(`Source failed: ${result.reason?.message}`);
  return null;
}

// ── Helper: merge all sources, best quality wins per app ─────
function mergeFares({ scrape, formula }) {
  const apps = ['uber', 'bolt', 'grab', 'indrive', 'ola', 'lyft', 'careem', 'meter'];
  const merged = [];

  for (const app of apps) {
    // Priority: live scrape > formula
    const scraped  = scrape[app];
    const formulae = formula?.filter(f => f.app === app) || [];

    if (scraped && Array.isArray(scraped) && scraped.length > 0) {
      // Use live scraped data
      scraped.forEach(f => merged.push({ ...f, source: 'live' }));
    } else if (formulae.length > 0) {
      // Fall back to formula
      formulae.forEach(f => merged.push({ ...f, source: 'formula' }));
    }
  }

  // Sort by midpoint fare (cheapest first)
  return merged.sort((a, b) => {
    const midA = (a.low + a.high) / 2;
    const midB = (b.low + b.high) / 2;
    return midA - midB;
  });
}

module.exports = router;
