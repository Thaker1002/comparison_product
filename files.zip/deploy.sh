#!/bin/bash
# ============================================================
#  deploy.sh — One-command deploy to Ubuntu VPS
#  Tested on: DigitalOcean Ubuntu 22.04 ($12/month droplet)
#  Run as: bash deploy.sh
# ============================================================
set -e

echo ""
echo "=== RIDE FARE SERVER DEPLOYMENT ==="
echo ""

# ── 1. System packages ────────────────────────────────────────
echo "→ Installing system packages..."
apt-get update -qq
apt-get install -y -q nodejs npm git curl redis-server

# ── 2. Node 20 (LTS) ─────────────────────────────────────────
NODE_VERSION=$(node --version 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1)
if [ "${NODE_VERSION:-0}" -lt "18" ]; then
  echo "→ Upgrading Node.js to v20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
echo "   Node: $(node --version)  npm: $(npm --version)"

# ── 3. PM2 process manager ─────────────────────────────────────
echo "→ Installing PM2..."
npm install -g pm2 --silent

# ── 4. Project setup ─────────────────────────────────────────
echo "→ Installing project dependencies..."
npm install --silent

# ── 5. Playwright Chromium ────────────────────────────────────
echo "→ Installing Playwright Chromium (this takes ~2 minutes)..."
npx playwright install chromium --with-deps

# ── 6. Redis ─────────────────────────────────────────────────
echo "→ Starting Redis..."
systemctl enable redis-server
systemctl start redis-server
echo "   Redis: $(redis-cli ping)"

# ── 7. Environment file ───────────────────────────────────────
if [ ! -f .env ]; then
  echo "→ Creating .env from template..."
  cp .env.example .env
  echo ""
  echo "  ⚠️  IMPORTANT: Edit .env and add your GOOGLE_MAPS_KEY"
  echo "  Run: nano .env"
  echo ""
fi

# ── 8. PM2 configuration ─────────────────────────────────────
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'fare-server',
    script: 'server.js',
    instances: 1,           // increase to 'max' for multi-core
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production',
      PORT: 3001,
    },
    error_file: './logs/err.log',
    out_file:   './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
  }]
};
EOF

mkdir -p logs

# ── 9. Start with PM2 ────────────────────────────────────────
echo "→ Starting server with PM2..."
pm2 delete fare-server 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save
pm2 startup | tail -1 | bash   # auto-start on reboot

# ── 10. Test ─────────────────────────────────────────────────
sleep 2
echo ""
echo "→ Testing server..."
HEALTH=$(curl -s http://localhost:3001/health 2>/dev/null || echo '{"status":"error"}')
echo "   Health: $HEALTH"

FORMULA=$(curl -s http://localhost:3001/health/formula 2>/dev/null || echo '{"status":"error"}')
echo "   Formula: $FORMULA"

echo ""
echo "=== DEPLOYMENT COMPLETE ==="
echo ""
echo "Server running at: http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_IP'):3001"
echo ""
echo "Useful commands:"
echo "  pm2 logs fare-server     # view live logs"
echo "  pm2 status               # check process status"
echo "  pm2 restart fare-server  # restart after code changes"
echo "  pm2 stop fare-server     # stop server"
echo ""
echo "Next steps:"
echo "  1. Add your GOOGLE_MAPS_KEY to .env"
echo "  2. (Optional) Add PROXY_URL to .env for better scraping"
echo "  3. Set up HTTPS with: apt install certbot nginx"
echo ""
