# Ride Fare Comparison Server

Node.js backend API for your ride comparison app.
Returns fares from Uber, Bolt, Grab, inDrive, Ola, Careem, Lyft, and metered taxis.

## How it works

```
Mobile App  →  POST /api/fares  →  Your Server
                                    ├── Playwright scrapes Uber live  (98–100% accurate)
                                    ├── Playwright scrapes Bolt live  (90–98% accurate)
                                    ├── Formula engine (Grab, inDrive, Ola, Careem)
                                    └── Returns merged JSON, sorted cheapest first
```

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Install Chromium for Playwright
npm run install-browsers

# 3. Copy env file and add your Google Maps key
cp .env.example .env
# Edit .env — add GOOGLE_MAPS_KEY

# 4. Start server
npm run dev        # development (auto-restart)
npm start          # production

# 5. Test formula engine (no server needed)
npm test
```

## API

### POST /api/fares

**Request body:**
```json
{
  "pickup":  { "lat": 13.7563, "lng": 100.5018 },
  "dropoff": { "lat": 13.7400, "lng": 100.5300 },
  "country": "TH",
  "city":    "Bangkok"
}
```

**Response:**
```json
{
  "fares": [
    {
      "app":      "bolt",
      "service":  "Bolt Economy",
      "low":      86,
      "high":     106,
      "currency": "THB",
      "source":   "live"
    },
    {
      "app":      "grab",
      "service":  "GrabCar Economy",
      "low":      149,
      "high":     182,
      "currency": "THB",
      "source":   "formula"
    }
  ],
  "route": {
    "distanceKm": 8.3,
    "durationMin": 23,
    "distanceText": "8.3 km",
    "durationText": "23 mins"
  },
  "city":      "Bangkok",
  "country":   "TH",
  "fetchedAt": "2025-04-01T10:00:00.000Z",
  "cached":    false
}
```

**Source values:**
- `"live"` — intercepted directly from Uber/Bolt API (98–100% accurate)
- `"formula"` — calculated from fare rate table (80–90% accurate)

## Country codes

| Code | Country | Cities covered |
|------|---------|----------------|
| TH | Thailand | Bangkok, Chiang Mai |
| SG | Singapore | Singapore |
| MY | Malaysia | Kuala Lumpur |
| ID | Indonesia | Jakarta |
| IN | India | Mumbai, Delhi, Bangalore |
| AE | UAE | Dubai, Abu Dhabi |
| US | USA | New York, Los Angeles |
| CA | Canada | Toronto, Vancouver |

## Project structure

```
fare-server/
├── server.js              Main Express app
├── routes/
│   └── fares.js           POST /api/fares — orchestrator
├── scrapers/
│   ├── uber.js            Playwright API interceptor for Uber
│   └── bolt.js            Playwright API interceptor for Bolt
├── formula/
│   └── calculator.js      Formula engine (no scraping needed)
├── data/
│   └── fareRates.js       Fare rates DB — update quarterly
├── utils/
│   ├── googleMaps.js      Distance + duration via Google Maps
│   ├── cache.js           Redis + in-memory cache
│   └── logger.js          Simple timestamped logger
└── test/
    └── testFares.js       Tests formula engine directly
```

## Deployment (DigitalOcean $12/month droplet)

```bash
# On your server (Ubuntu 22.04)
git clone your-repo
cd fare-server
npm install
npm run install-browsers

# Install PM2 process manager
npm install -g pm2
pm2 start server.js --name fare-server
pm2 startup    # auto-start on reboot
pm2 save
```

## Updating fare rates

Edit `data/fareRates.js` — do this quarterly or when users report fares are off.
Sources for current rates:
- taxifarefinder.com (most cities)
- ride.guru (USA/Canada)
- Official app help pages
