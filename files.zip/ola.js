// ============================================================
//  OLA SCRAPER — uses official affiliate deep link + web API
//  Ola has a documented affiliate URL with fare estimate
//  URL: https://book.olacabs.com/?lat=&lng=&drop_lat=&drop_lng=
// ============================================================
const { log, warn } = require('../utils/logger');

// Ola's public web booking endpoint — no login required
const OLA_WEB_URL = 'https://book.olacabs.com/';

// Ola affiliate API (requires utm_source token from developers.olacabs.com)
// Without a token, we scrape their web page instead
const OLA_AFFILIATE_URL = 'https://olawebcdn.com/assets/ola-universal-link.html';

async function scrapeOla(pickup, dropoff) {
  // Only relevant for India
  log('[Ola] Starting scrape');

  let browser = null;
  try {
    // Use playwright-extra with stealth
    const { chromium } = require('playwright-extra');
    const stealth = require('puppeteer-extra-plugin-stealth');
    chromium.use(stealth());

    const HEADLESS  = process.env.SCRAPER_HEADLESS !== 'false';
    const PROXY_URL = process.env.PROXY_URL;

    const launchOptions = {
      headless: HEADLESS,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    };
    if (PROXY_URL) launchOptions.proxy = { server: PROXY_URL };

    browser = await chromium.launch(launchOptions);
    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      locale: 'en-IN',
      geolocation: { latitude: pickup.lat, longitude: pickup.lng },
      permissions: ['geolocation'],
    });

    const page = await context.newPage();

    // ── Intercept Ola's internal pricing API ─────────────────
    let capturedFares = null;

    await page.route('**/v1/products**', async (route) => {
      try {
        const response = await route.fetch();
        const json = await response.json().catch(() => null);
        if (json?.ride_estimate || json?.categories || json?.products) {
          capturedFares = json.ride_estimate || json.categories || json.products;
          log(`[Ola] Intercepted ${capturedFares?.length || '?'} products`);
        }
        await route.fulfill({ response });
      } catch (e) { await route.continue(); }
    });

    await page.route('**/v2/products**', async (route) => {
      try {
        const response = await route.fetch();
        const json = await response.json().catch(() => null);
        if (json && !capturedFares) {
          capturedFares = json.categories || json.products || json.data;
        }
        await route.fulfill({ response });
      } catch (e) { await route.continue(); }
    });

    // ── Navigate to Ola web booking ───────────────────────────
    const url = `${OLA_WEB_URL}?lat=${pickup.lat}&lng=${pickup.lng}&drop_lat=${dropoff.lat}&drop_lng=${dropoff.lng}`;
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForTimeout(3000);

    // Wait for API capture
    const startWait = Date.now();
    while (!capturedFares && (Date.now() - startWait) < 10000) {
      await page.waitForTimeout(400);
    }

    await browser.close();

    if (!capturedFares) {
      warn('[Ola] No fares intercepted');
      return null;
    }

    return formatOlaFares(capturedFares);

  } catch (err) {
    warn(`[Ola] Scraper error: ${err.message}`);
    if (browser) await browser.close().catch(() => {});
    return null;
  }
}

function formatOlaFares(products) {
  if (!Array.isArray(products)) return null;

  return products
    .filter(p => p && (p.amount || p.fare || p.price))
    .map(p => {
      const amount = p.amount || p.fare || p.price || {};
      const low    = amount.minimum_fare || amount.min || amount.value || amount;
      const high   = amount.maximum_fare || amount.max || amount.value || amount;

      if (!low) return null;
      return {
        app:      'ola',
        service:  p.display_name || p.name || p.category || 'Ola',
        low:      Math.round(low),
        high:     Math.round(high || low * 1.15),
        currency: 'INR',
        source:   'live',
      };
    })
    .filter(Boolean);
}

module.exports = { scrapeOla };
