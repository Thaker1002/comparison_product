// ============================================================
//  BOLT SCRAPER — API interception via Playwright
//  Intercepts: node.bolt.eu/booking/v1/price  (or similar)
//  URL pattern: bolt.eu/en-[country]/ride/
// ============================================================
const { chromium }  = require('playwright-extra');
const stealth       = require('puppeteer-extra-plugin-stealth');
const { log, warn } = require('../utils/logger');

chromium.use(stealth());

const TIMEOUT  = parseInt(process.env.SCRAPER_TIMEOUT_MS) || 18000;
const HEADLESS = process.env.SCRAPER_HEADLESS !== 'false';
const PROXY_URL = process.env.PROXY_URL;

// Country code → Bolt locale path
const BOLT_LOCALE = {
  TH: 'en-th', SG: 'en-sg', MY: 'en-my',
  ID: 'en-id', IN: 'en-in', AE: 'en-ae',
  US: 'en-us', CA: 'en-ca',
};

const CURRENCY = {
  TH: 'THB', SG: 'SGD', MY: 'MYR', ID: 'IDR',
  IN: 'INR', AE: 'AED', US: 'USD', CA: 'CAD',
};

async function scrapeBolt(pickup, dropoff, country, city) {
  const locale = BOLT_LOCALE[country];
  if (!locale) {
    warn(`[Bolt] No locale mapping for country: ${country}`);
    return null;
  }

  log(`[Bolt] Starting scrape for ${country} (${locale})`);
  let browser = null;

  try {
    const launchOptions = {
      headless: HEADLESS,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
    };
    if (PROXY_URL) launchOptions.proxy = { server: PROXY_URL };

    browser = await chromium.launch(launchOptions);
    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      locale: 'en-US',
      geolocation: { latitude: pickup.lat, longitude: pickup.lng },
      permissions: ['geolocation'],
      viewport: { width: 390, height: 844 },
    });

    const page = await context.newPage();

    // ── API interceptor — catch Bolt's price endpoint ────────
    let capturedFares = null;

    // Bolt uses several possible endpoints — catch all patterns
    const boltPatterns = [
      '**/booking/v1/price**',
      '**/booking/v2/price**',
      '**/ride/v1/search**',
      '**/price/v1**',
      '**bolt.eu/booking/**',
    ];

    for (const pattern of boltPatterns) {
      await page.route(pattern, async (route) => {
        try {
          const response = await route.fetch();
          const json = await response.json().catch(() => null);
          if (json && !capturedFares) {
            // Bolt response can be nested in different ways
            const prices =
              json.data?.categories  ||
              json.categories        ||
              json.data?.products    ||
              json.products          ||
              (Array.isArray(json) ? json : null);

            if (prices?.length > 0) {
              capturedFares = prices;
              log(`[Bolt] Captured ${prices.length} fare types from ${pattern}`);
            }
          }
          await route.fulfill({ response });
        } catch (e) {
          await route.continue();
        }
      });
    }

    // ── Navigate to Bolt's ride estimate page ────────────────
    const boltUrl = `https://bolt.eu/${locale}/ride/`;
    await page.goto(boltUrl, { waitUntil: 'domcontentloaded', timeout: TIMEOUT });
    await page.waitForTimeout(1500);

    // ── Fill pickup via address input ─────────────────────────
    const pickupFilled = await fillBoltAddress(page, 'pickup', pickup);
    if (!pickupFilled) {
      // Alternative: try passing coords directly as URL params
      const coordUrl = `https://bolt.eu/${locale}/ride/?` +
        `startLat=${pickup.lat}&startLng=${pickup.lng}` +
        `&endLat=${dropoff.lat}&endLng=${dropoff.lng}`;
      await page.goto(coordUrl, { waitUntil: 'networkidle', timeout: TIMEOUT });
    } else {
      await humanDelay(700, 1200);
      await fillBoltAddress(page, 'dropoff', dropoff);
    }

    // ── Wait for price API to fire ────────────────────────────
    const startWait = Date.now();
    while (!capturedFares && (Date.now() - startWait) < 12000) {
      await page.waitForTimeout(300);
    }

    await browser.close();

    if (!capturedFares) {
      warn('[Bolt] No fares intercepted');
      return null;
    }

    return formatBoltFares(capturedFares, country);

  } catch (err) {
    warn(`[Bolt] Scraper error: ${err.message}`);
    if (browser) await browser.close().catch(() => {});
    return null;
  }
}

async function fillBoltAddress(page, field, coords) {
  try {
    const selectors = [
      `[placeholder*="${field === 'pickup' ? 'Pick up' : 'Destination'}"]`,
      `[placeholder*="${field === 'pickup' ? 'pickup' : 'drop'}"]`,
      `[data-testid="${field}-address"]`,
      `input[name="${field}"]`,
    ];

    let input = null;
    for (const sel of selectors) {
      input = await page.$(sel);
      if (input) break;
    }
    if (!input) return false;

    await input.click();
    await page.waitForTimeout(300);
    await input.type(`${coords.lat}, ${coords.lng}`, { delay: 60 });
    await page.waitForTimeout(1000);

    // Select first autocomplete suggestion
    const option = await page.$('[role="option"], [class*="suggestion"], [class*="option"]');
    if (option) {
      await option.click();
      return true;
    }
    await page.keyboard.press('ArrowDown');
    await page.keyboard.press('Enter');
    return true;

  } catch (e) {
    return false;
  }
}

// ── Normalise Bolt's various API response shapes ─────────────
function formatBoltFares(prices, country) {
  const currency = CURRENCY[country] || 'EUR';
  return prices
    .filter(p => p && (p.price || p.total_price || p.fare))
    .map(p => {
      // Bolt's API has changed shape several times — handle all known shapes
      const name   = p.name || p.display_name || p.category_name || 'Bolt Car';
      const price  = p.price || p.total_price || p.fare || {};
      const low    = price.min_price ?? price.min ?? price.value ?? price;
      const high   = price.max_price ?? price.max ?? price.value ?? price;

      if (!low || !high) return null;
      return {
        app:      'bolt',
        service:  name,
        low:      Math.round(typeof low === 'number' ? low : low / 100),
        high:     Math.round(typeof high === 'number' ? high : high / 100),
        currency,
        source:   'live',
      };
    })
    .filter(Boolean);
}

const humanDelay = (min, max) =>
  new Promise(r => setTimeout(r, min + Math.random() * (max - min)));

module.exports = { scrapeBolt };
