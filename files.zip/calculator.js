// ============================================================
//  FORMULA CALCULATOR
//  Calculates fares for all apps in a city using the rates DB
//  This is always the fallback when live scraping fails
// ============================================================
const { FARE_RATES } = require('../data/fareRates');
const { warn } = require('../utils/logger');

// ── Main function: calculate all fares for a city ────────────
function calcAllFares(distanceKm, durationMin, country, city) {
  const countryData = FARE_RATES[country];
  if (!countryData) {
    warn(`[Formula] No rates for country: ${country}`);
    return [];
  }

  // Try exact city match, then fuzzy match
  const cityData = countryData[city] || findClosestCity(countryData, city);
  if (!cityData) {
    warn(`[Formula] No rates for city: ${city} in ${country}`);
    return [];
  }

  return cityData.apps.map(app => calcFare(app, distanceKm, durationMin, cityData.currency));
}

// ── Single fare calculation ───────────────────────────────────
function calcFare(rateEntry, distanceKm, durationMin, currency) {
  let distanceCost = 0;

  // Tiered km pricing (Bangkok meter taxi uses this)
  if (rateEntry.kmTiers) {
    distanceCost = calcTieredKm(rateEntry.kmTiers, distanceKm);
  } else {
    distanceCost = distanceKm * (rateEntry.perKm || 0);
  }

  const timeCost   = durationMin * (rateEntry.perMin || 0);
  const rawFare    = (rateEntry.base || 0) + distanceCost + timeCost + (rateEntry.booking || 0);
  const finalFare  = Math.max(rawFare, rateEntry.minFare || 0);

  // For inDrive: show wider range since it's negotiated
  const isNegotiated = rateEntry.note?.toLowerCase().includes('negotiat');
  const rangePct = isNegotiated ? 0.20 : 0.10; // ±20% for inDrive, ±10% otherwise

  return {
    app:      rateEntry.app,
    service:  rateEntry.service,
    low:      Math.round(finalFare * (1 - rangePct)),
    high:     Math.round(finalFare * (1 + rangePct)),
    midpoint: Math.round(finalFare),
    currency: currency,
    source:   'formula',
    note:     rateEntry.note || null,
  };
}

// ── Tiered km rate calculator (Bangkok taxi style) ───────────
function calcTieredKm(tiers, totalKm) {
  let cost     = 0;
  let prevMax  = 0;

  for (const tier of tiers) {
    if (totalKm <= prevMax) break;
    const kmInTier = Math.min(totalKm, tier.upToKm) - prevMax;
    if (kmInTier > 0) cost += kmInTier * tier.rate;
    prevMax = tier.upToKm;
    if (totalKm <= tier.upToKm) break;
  }

  return cost;
}

// ── Fuzzy city match (handles "Kuala Lumpur" vs "KL" etc.) ───
function findClosestCity(countryData, cityName) {
  const normalised = cityName.toLowerCase().trim();
  for (const [key, value] of Object.entries(countryData)) {
    if (key.toLowerCase().includes(normalised) ||
        normalised.includes(key.toLowerCase())) {
      return value;
    }
  }
  // Return first city as absolute fallback
  const firstCity = Object.values(countryData)[0];
  return firstCity || null;
}

module.exports = { calcAllFares, calcFare };
