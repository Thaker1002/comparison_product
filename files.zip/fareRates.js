// ============================================================
//  FARE RATES DATABASE
//  Verified rates for all 8 countries — update quarterly
//  Last verified: Q1 2025
//
//  Formula: fare = base + (distanceKm × perKm) + (durationMin × perMin) + booking
//  Final fare = max(calculated, minFare)
// ============================================================

const FARE_RATES = {

  // ── THAILAND ───────────────────────────────────────────────
  TH: {
    Bangkok: {
      currency: 'THB',
      apps: [
        {
          app: 'meter',
          service: 'Meter Taxi',
          base: 35,
          booking: 0,
          minFare: 35,
          perMin: 3.0, // when stopped in traffic
          kmTiers: [     // Bangkok uses tiered per-km rates
            { upToKm: 1,   rate: 0   },  // included in base
            { upToKm: 10,  rate: 6.5 },
            { upToKm: 20,  rate: 7.0 },
            { upToKm: 40,  rate: 8.0 },
            { upToKm: 60,  rate: 8.5 },
            { upToKm: 80,  rate: 9.0 },
            { upToKm: 999, rate: 10.5 },
          ],
          note: 'Add ฿20 Grab surcharge if booked via GrabTaxi',
        },
        { app:'grab', service:'GrabCar Economy',   base:45,  perKm:9.0,  perMin:2.0, booking:0,  minFare:65  },
        { app:'grab', service:'GrabCar Premium',   base:110, perKm:13.0, perMin:2.5, booking:0,  minFare:110 },
        { app:'grab', service:'GrabBike',          base:20,  perKm:4.0,  perMin:1.0, booking:0,  minFare:25  },
        { app:'bolt', service:'Bolt Economy',      base:20,  perKm:5.0,  perMin:1.5, booking:0,  minFare:50  },
        { app:'bolt', service:'Bolt Premium',      base:80,  perKm:9.0,  perMin:2.0, booking:0,  minFare:80  },
        { app:'uber', service:'UberX',             base:50,  perKm:8.0,  perMin:2.0, booking:15, minFare:65  },
        { app:'uber', service:'Uber Comfort',      base:80,  perKm:11.0, perMin:2.5, booking:15, minFare:90  },
        { app:'indrive', service:'inDrive Car',    base:50,  perKm:5.0,  perMin:1.5, booking:0,  minFare:50,
          note:'Negotiated — show as suggested range ±20%' },
      ],
    },
    'Chiang Mai': {
      currency: 'THB',
      apps: [
        { app:'grab', service:'GrabCar Economy',  base:40, perKm:8.0, perMin:1.8, booking:0, minFare:55 },
        { app:'bolt', service:'Bolt Economy',     base:18, perKm:4.5, perMin:1.3, booking:0, minFare:45 },
        { app:'indrive', service:'inDrive Car',   base:40, perKm:4.5, perMin:1.3, booking:0, minFare:40 },
      ],
    },
  },

  // ── SINGAPORE ─────────────────────────────────────────────
  SG: {
    Singapore: {
      currency: 'SGD',
      apps: [
        { app:'grab', service:'GrabCar Economy',  base:3.50, perKm:0.50, perMin:0.20, booking:0,    minFare:5.00 },
        { app:'grab', service:'GrabCar Standard', base:5.00, perKm:0.65, perMin:0.25, booking:0,    minFare:7.00 },
        { app:'grab', service:'GrabCar Premium',  base:7.00, perKm:0.90, perMin:0.30, booking:0,    minFare:10.00 },
        { app:'bolt', service:'Bolt Economy',     base:3.00, perKm:0.45, perMin:0.18, booking:0,    minFare:4.50 },
        { app:'uber', service:'UberX',            base:3.80, perKm:0.55, perMin:0.22, booking:0.90, minFare:6.00 },
        { app:'indrive', service:'inDrive Car',   base:3.00, perKm:0.40, perMin:0.15, booking:0,    minFare:4.00 },
      ],
    },
  },

  // ── MALAYSIA ──────────────────────────────────────────────
  MY: {
    'Kuala Lumpur': {
      currency: 'MYR',
      apps: [
        { app:'grab', service:'GrabCar Economy',  base:2.00, perKm:0.55, perMin:0.12, booking:0,    minFare:4.00 },
        { app:'grab', service:'GrabCar Standard', base:3.00, perKm:0.70, perMin:0.15, booking:0,    minFare:5.00 },
        { app:'bolt', service:'Bolt Economy',     base:1.80, perKm:0.48, perMin:0.10, booking:0,    minFare:3.50 },
        { app:'uber', service:'UberX',            base:2.50, perKm:0.60, perMin:0.14, booking:0.70, minFare:4.50 },
        { app:'indrive', service:'inDrive Car',   base:2.00, perKm:0.45, perMin:0.10, booking:0,    minFare:3.00 },
      ],
    },
  },

  // ── INDONESIA ─────────────────────────────────────────────
  ID: {
    Jakarta: {
      currency: 'IDR',
      apps: [
        { app:'grab', service:'GrabCar Economy',  base:10000, perKm:3500, perMin:400, booking:0,    minFare:12000 },
        { app:'grab', service:'GrabBike',         base:5000,  perKm:2000, perMin:300, booking:0,    minFare:6000  },
        { app:'uber', service:'UberX',            base:12000, perKm:4000, perMin:450, booking:2000, minFare:15000 },
        { app:'indrive', service:'inDrive Car',   base:9000,  perKm:3000, perMin:350, booking:0,    minFare:10000 },
        { app:'gojek', service:'GoRide',          base:5000,  perKm:2200, perMin:300, booking:0,    minFare:6000  },
        { app:'gojek', service:'GoCar',           base:10000, perKm:3500, perMin:400, booking:0,    minFare:12000 },
      ],
    },
  },

  // ── INDIA ─────────────────────────────────────────────────
  IN: {
    Mumbai: {
      currency: 'INR',
      apps: [
        { app:'ola', service:'Ola Micro',    base:40, perKm:8.0,  perMin:1.0, booking:0, minFare:60  },
        { app:'ola', service:'Ola Mini',     base:50, perKm:10.0, perMin:1.2, booking:0, minFare:75  },
        { app:'ola', service:'Ola Prime',    base:75, perKm:14.0, perMin:1.5, booking:0, minFare:100 },
        { app:'ola', service:'Ola Auto',     base:25, perKm:6.0,  perMin:0.8, booking:0, minFare:35  },
        { app:'uber', service:'UberGo',      base:40, perKm:9.0,  perMin:1.0, booking:0, minFare:65  },
        { app:'uber', service:'Uber Auto',   base:25, perKm:6.5,  perMin:0.8, booking:0, minFare:35  },
        { app:'indrive', service:'inDrive',  base:35, perKm:7.0,  perMin:0.9, booking:0, minFare:45  },
      ],
    },
    Delhi: {
      currency: 'INR',
      apps: [
        { app:'ola', service:'Ola Micro',    base:40, perKm:7.5,  perMin:1.0, booking:0, minFare:55  },
        { app:'ola', service:'Ola Mini',     base:45, perKm:9.5,  perMin:1.1, booking:0, minFare:70  },
        { app:'uber', service:'UberGo',      base:40, perKm:8.5,  perMin:1.0, booking:0, minFare:60  },
        { app:'indrive', service:'inDrive',  base:35, perKm:6.5,  perMin:0.8, booking:0, minFare:40  },
      ],
    },
    Bangalore: {
      currency: 'INR',
      apps: [
        { app:'ola', service:'Ola Micro',    base:45, perKm:8.0,  perMin:1.0, booking:0, minFare:60  },
        { app:'uber', service:'UberGo',      base:45, perKm:9.0,  perMin:1.0, booking:0, minFare:65  },
        { app:'indrive', service:'inDrive',  base:40, perKm:7.0,  perMin:0.9, booking:0, minFare:48  },
      ],
    },
  },

  // ── UAE / DUBAI ────────────────────────────────────────────
  AE: {
    Dubai: {
      currency: 'AED',
      apps: [
        { app:'uber', service:'UberX',          base:7.00, perKm:1.65, perMin:0.35, booking:0,    minFare:12.00 },
        { app:'uber', service:'Uber Comfort',   base:9.00, perKm:2.10, perMin:0.45, booking:0,    minFare:15.00 },
        { app:'careem', service:'Careem Go',    base:7.50, perKm:1.70, perMin:0.38, booking:0,    minFare:13.00 },
        { app:'careem', service:'Careem Bus',   base:4.00, perKm:0.90, perMin:0.20, booking:0,    minFare:6.00  },
        { app:'bolt', service:'Bolt Economy',   base:6.00, perKm:1.50, perMin:0.30, booking:0,    minFare:10.00 },
        { app:'indrive', service:'inDrive Car', base:6.00, perKm:1.40, perMin:0.28, booking:0,    minFare:9.00  },
      ],
    },
    'Abu Dhabi': {
      currency: 'AED',
      apps: [
        { app:'uber', service:'UberX',         base:7.50, perKm:1.70, perMin:0.35, booking:0, minFare:12.00 },
        { app:'careem', service:'Careem Go',   base:8.00, perKm:1.75, perMin:0.38, booking:0, minFare:13.00 },
      ],
    },
  },

  // ── USA ────────────────────────────────────────────────────
  US: {
    'New York': {
      currency: 'USD',
      apps: [
        { app:'uber', service:'UberX',         base:3.50, perKm:1.12, perMin:0.30, booking:3.50, minFare:8.00  },
        { app:'uber', service:'UberXL',        base:5.00, perKm:1.70, perMin:0.45, booking:3.50, minFare:12.00 },
        { app:'uber', service:'Uber Comfort',  base:4.50, perKm:1.35, perMin:0.35, booking:3.50, minFare:10.00 },
        { app:'lyft', service:'Lyft',          base:3.20, perKm:1.08, perMin:0.28, booking:2.75, minFare:7.50  },
        { app:'lyft', service:'Lyft XL',       base:4.50, perKm:1.60, perMin:0.42, booking:2.75, minFare:11.00 },
        { app:'indrive', service:'inDrive Car',base:3.00, perKm:0.95, perMin:0.25, booking:0,    minFare:7.00  },
      ],
    },
    'Los Angeles': {
      currency: 'USD',
      apps: [
        { app:'uber', service:'UberX',        base:2.50, perKm:1.00, perMin:0.25, booking:2.75, minFare:7.00  },
        { app:'lyft', service:'Lyft',         base:2.30, perKm:0.95, perMin:0.22, booking:2.50, minFare:6.50  },
      ],
    },
  },

  // ── CANADA ────────────────────────────────────────────────
  CA: {
    Toronto: {
      currency: 'CAD',
      apps: [
        { app:'uber', service:'UberX',         base:3.25, perKm:1.35, perMin:0.28, booking:2.50, minFare:7.00  },
        { app:'uber', service:'UberXL',        base:5.00, perKm:2.00, perMin:0.45, booking:2.50, minFare:11.00 },
        { app:'lyft', service:'Lyft',          base:3.00, perKm:1.25, perMin:0.25, booking:2.25, minFare:6.50  },
        { app:'indrive', service:'inDrive Car',base:2.75, perKm:1.10, perMin:0.22, booking:0,    minFare:6.00  },
      ],
    },
    Vancouver: {
      currency: 'CAD',
      apps: [
        { app:'uber', service:'UberX',        base:3.00, perKm:1.30, perMin:0.26, booking:2.50, minFare:6.50 },
        { app:'lyft', service:'Lyft',         base:2.80, perKm:1.20, perMin:0.23, booking:2.25, minFare:6.00 },
      ],
    },
  },
};

module.exports = { FARE_RATES };
