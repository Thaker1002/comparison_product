// ============================================================
//  UBER SCRAPER — API interception via Playwright
//  Intercepts: api.uber.com/v1.2/estimates/price
//  No login required — uses public estimate page
// ============================================================
const { chromium }  = require('playwright-extra');
const stealth       = require('puppeteer-extra-plugin-stealth');
const { log, warn } = require('../utils/logger');

chromium.use(stealth());

const TIMEOUT     = parseInt(process.env.SCRAPER_TIMEOUT_MS) || 18000;
const HEADLESS    = process.env.SCRAPER_HEADLESS !== 'false';
const PROXY_URL   = process.env.PROXY_URL;

// ── Uber estimate page URL (public, no login) ────────────────
const UBER_ESTIMATE_URL = 'https://www.uber.com/global/en/price-estimate/';

// ── Currency codes by country ────────────────────────────────
const CURRENCY = {
  TH: 'THB', SG: 'SGD', MY: 'MYR', ID: 'IDR',
  IN: 'INR', AE: 'AED', US: 'USD', CA: 'CAD',
};

// ── Main scraper function ─────────────────────────────────────
async function scrapeUber(pickup, dropoff, country) {
  log(`[Uber] Starting scrape for ${country}`);
  let browser = null;

  try {
    // ── Launch browser ──────────────────────────────────────
    const launchOptions = {
      headless: HEADLESS,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu',
        '--window-size=1280,800',
      ],
    };
    if (PROXY_URL) {
      launchOptions.proxy = { server: PROXY_URL };
    }
    browser = await chromium.launch(launchOptions);

    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
      locale: 'en-US',
      timezoneId: getTimezone(country),
      geolocation: { latitude: pickup.lat, longitude: pickup.lng },
      permissions: ['geolocation'],
      viewport: { width: 390, height: 844 }, // iPhone 14 size
    });

    const page = await context.newPage();

    // ── Step 1: Install API interceptor BEFORE navigating ───
    let capturedFares    = null;
    let captureTimestamp = null;

    await page.route('**/*estimates/price*', async (route) => {
      log('[Uber] Intercepted fare estimate API call');
      try {
        const response = await route.fetch();
        const json     = await response.json().catch(() => null);
        if (json?.prices?.length > 0) {
          capturedFares    = json.prices;
          captureTimestamp = Date.now();
          log(`[Uber] Captured ${json.prices.length} fare types`);
        }
        await route.fulfill({ response });
      } catch (e) {
        warn(`[Uber] Route intercept error: ${e.message}`);
        await route.continue();
      }
    });

    // Also try the v2 endpoint format
    await page.route('**/*v2/estimates*', async (route) => {
      try {
        const response = await route.fetch();
        const json     = await response.json().catch(() => null);
        if (json?.data?.prices?.length > 0 && !capturedFares) {
          capturedFares = json.data.prices;
          log(`[Uber] Captured fares from v2 endpoint`);
        }
        await route.fulfill({ response });
      } catch (e) {
        await route.continue();
      }
    });

    // ── Step 2: Navigate to estimate page ───────────────────
    await page.goto(UBER_ESTIMATE_URL, {
      waitUntil: 'domcontentloaded',
      timeout: TIMEOUT,
    });

    // Small wait for page JS to initialise
    await page.waitForTimeout(1500 + Math.random() * 1000);

    // ── Step 3: Fill pickup address ──────────────────────────
    const pickupFilled = await fillAddress(page, 'pickup', pickup);
    if (!pickupFilled) {
      warn('[Uber] Could not fill pickup address');
      await browser.close();
      return null;
    }
    await humanDelay(800, 1400);

    // ── Step 4: Fill dropoff address ─────────────────────────
    const dropoffFilled = await fillAddress(page, 'dropoff', dropoff);
    if (!dropoffFilled) {
      warn('[Uber] Could not fill dropoff address');
      await browser.close();
      return null;
    }

    // ── Step 5: Wait for API call to fire (up to 12 seconds) ─
    const startWait = Date.now();
    while (!capturedFares && (Date.now() - startWait) < 12000) {
      await page.waitForTimeout(300);
    }

    await browser.close();

    if (!capturedFares) {
      warn('[Uber] No fares intercepted — API call did not fire');
      return null;
    }

    // ── Step 6: Format and return results ────────────────────
    return formatUberFares(capturedFares, country);

  } catch (err) {
    warn(`[Uber] Scraper error: ${err.message}`);
    if (browser) await browser.close().catch(() => {});
    return null;
  }
}

// ── Fill an address field by coordinates → reverse geocode ───
async function fillAddress(page, field, coords) {
  try {
    // Try different selector patterns (Uber A/B tests their UI)
    const selectors = [
      `[data-testid="${field}-input"]`,
      `[placeholder*="${field === 'pickup' ? 'Pickup' : 'Dropoff'}"]`,
      `[placeholder*="${field === 'pickup' ? 'pickup' : 'destination'}"]`,
      `input[name="${field}"]`,
      `#${field}-location`,
    ];

    let input = null;
    for (const sel of selectors) {
      input = await page.$(sel);
      if (input) break;
    }

    if (!input) {
      // Last resort: find input by position
      const inputs = await page.$$('input[type="text"]');
      input = inputs[field === 'pickup' ? 0 : 1];
    }
    if (!input) return false;

    // Use lat,lng format which Uber accepts in estimate page
    await input.click();
    await page.waitForTimeout(300);
    await input.fill(`${coords.lat},${coords.lng}`);
    await page.waitForTimeout(800);

    // Wait for autocomplete dropdown and select first option
    const dropdown = await page.waitForSelector(
      '[role="option"], .css-option, [data-testid="location-option"]',
      { timeout: 4000 }
    ).catch(() => null);

    if (dropdown) {
      await dropdown.click();
      return true;
    }

    // If no dropdown, try pressing Enter
    await page.keyboard.press('Enter');
    return true;

  } catch (e) {
    warn(`[Uber] fillAddress(${field}) error: ${e.message}`);
    return false;
  }
}

// ── Format Uber API response to our standard shape ───────────
function formatUberFares(prices, country) {
  const currency = CURRENCY[country] || 'USD';
  return prices
    .filter(p => p.low_estimate > 0)
    .map(p => ({
      app:      'uber',
      service:  p.display_name,          // "UberX", "Comfort", "UberXL"
      low:      Math.round(p.low_estimate),
      high:     Math.round(p.high_estimate),
      currency,
      surge:    p.surge_multiplier || 1.0,
      duration: Math.round((p.duration || 0) / 60), // seconds → minutes
      distanceKm: p.distance ? parseFloat(p.distance.toFixed(1)) : null,
      source:   'live',
    }));
}

// ── Timezone by country ───────────────────────────────────────
function getTimezone(country) {
  const tzMap = {
    TH: 'Asia/Bangkok',   SG: 'Asia/Singapore',
    MY: 'Asia/Kuala_Lumpur', ID: 'Asia/Jakarta',
    IN: 'Asia/Kolkata',   AE: 'Asia/Dubai',
    US: 'America/New_York', CA: 'America/Toronto',
  };
  return tzMap[country] || 'UTC';
}

// ── Human-like random delay ───────────────────────────────────
const humanDelay = (min, max) =>
  new Promise(r => setTimeout(r, min + Math.random() * (max - min)));

module.exports = { scrapeUber };
