// ============================================================
//  GOOGLE MAPS UTILITY
//  Gets real road distance + traffic-aware duration
//  Falls back to Haversine straight-line if API unavailable
// ============================================================
const { warn, log } = require('./logger');

const GOOGLE_KEY = process.env.GOOGLE_MAPS_KEY;

async function getRoute(pickupLat, pickupLng, dropLat, dropLng) {
  // Try Google Maps Distance Matrix API first
  if (GOOGLE_KEY) {
    try {
      return await getGoogleRoute(pickupLat, pickupLng, dropLat, dropLng);
    } catch (err) {
      warn(`[Maps] Google API failed: ${err.message} — falling back to Haversine`);
    }
  } else {
    warn('[Maps] No GOOGLE_MAPS_KEY set — using Haversine estimate');
  }

  // Fallback: Haversine formula (straight-line × road factor)
  return getHaversineRoute(pickupLat, pickupLng, dropLat, dropLng);
}

// ── Google Maps Distance Matrix ──────────────────────────────
async function getGoogleRoute(pickupLat, pickupLng, dropLat, dropLng) {
  const url = new URL('https://maps.googleapis.com/maps/api/distancematrix/json');
  url.searchParams.set('origins',      `${pickupLat},${pickupLng}`);
  url.searchParams.set('destinations', `${dropLat},${dropLng}`);
  url.searchParams.set('mode',         'driving');
  url.searchParams.set('departure_time','now');          // enables live traffic
  url.searchParams.set('traffic_model','best_guess');
  url.searchParams.set('key',           GOOGLE_KEY);

  const res  = await fetch(url.toString(), { timeout: 8000 });
  const data = await res.json();

  if (data.status !== 'OK') throw new Error(`Maps API status: ${data.status}`);

  const element = data.rows?.[0]?.elements?.[0];
  if (!element || element.status !== 'OK') {
    throw new Error(`No route found between points`);
  }

  const distanceKm   = element.distance.value / 1000;
  const durationSec  = (element.duration_in_traffic || element.duration).value;
  const durationMin  = durationSec / 60;

  log(`[Maps] Route: ${distanceKm.toFixed(1)}km, ${Math.round(durationMin)}min`);

  return {
    distanceKm:   parseFloat(distanceKm.toFixed(2)),
    durationMin:  parseFloat(durationMin.toFixed(1)),
    durationText: element.duration_in_traffic?.text || element.duration.text,
    distanceText: element.distance.text,
    source:       'google',
  };
}

// ── Haversine fallback (no API key needed) ───────────────────
function getHaversineRoute(lat1, lng1, lat2, lng2) {
  const R    = 6371; // Earth radius km
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a    = Math.sin(dLat/2) ** 2 +
               Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2) ** 2;
  const c    = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  const straightLineKm = R * c;
  // Roads are ~35% longer than straight-line in urban areas
  const distanceKm     = parseFloat((straightLineKm * 1.35).toFixed(2));
  // Assume average 25 km/h in city traffic
  const durationMin    = parseFloat((distanceKm / 25 * 60).toFixed(1));

  warn(`[Maps] Using Haversine estimate: ${distanceKm}km, ${durationMin}min (±20% accuracy)`);

  return {
    distanceKm,
    durationMin,
    durationText: `${Math.round(durationMin)} mins (estimated)`,
    distanceText: `${distanceKm} km (estimated)`,
    source:       'haversine',
  };
}

const toRad = (deg) => deg * (Math.PI / 180);

module.exports = { getRoute };
