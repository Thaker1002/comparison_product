// ============================================================
//  CACHE UTILITY
//  Uses Redis when available, falls back to in-memory Map
//  Redis TTL is in seconds
// ============================================================
const { log, warn } = require('./logger');

let redisClient = null;
const memCache  = new Map(); // in-memory fallback

// ── Try to connect to Redis ───────────────────────────────────
async function initRedis() {
  if (!process.env.REDIS_URL) return;
  try {
    const { createClient } = require('redis');
    redisClient = createClient({ url: process.env.REDIS_URL });
    redisClient.on('error', (err) => {
      warn(`[Cache] Redis error: ${err.message} — using memory cache`);
      redisClient = null;
    });
    await redisClient.connect();
    log('[Cache] Redis connected');
  } catch (err) {
    warn(`[Cache] Redis unavailable: ${err.message} — using memory cache`);
    redisClient = null;
  }
}

// ── Get from cache ────────────────────────────────────────────
async function getCache(key) {
  try {
    if (redisClient) {
      const val = await redisClient.get(key);
      return val ? JSON.parse(val) : null;
    }
    // Memory cache with TTL check
    const entry = memCache.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      memCache.delete(key);
      return null;
    }
    return entry.value;
  } catch (err) {
    warn(`[Cache] getCache error: ${err.message}`);
    return null;
  }
}

// ── Set in cache ──────────────────────────────────────────────
async function setCache(key, value, ttlSeconds = 300) {
  try {
    if (redisClient) {
      await redisClient.setEx(key, ttlSeconds, JSON.stringify(value));
    } else {
      memCache.set(key, {
        value,
        expiresAt: Date.now() + ttlSeconds * 1000,
      });
      // Keep memory cache tidy — max 1000 entries
      if (memCache.size > 1000) {
        const firstKey = memCache.keys().next().value;
        memCache.delete(firstKey);
      }
    }
  } catch (err) {
    warn(`[Cache] setCache error: ${err.message}`);
  }
}

// Initialise Redis in background (non-blocking)
initRedis().catch(() => {});

module.exports = { getCache, setCache };
