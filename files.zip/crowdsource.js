// ============================================================
//  CROWDSOURCE ROUTES
//  POST /api/fares/submit  — user submits actual fare paid
//  GET  /api/fares/crowd   — get crowdsourced fares for a route
// ============================================================
const express      = require('express');
const router       = express.Router();
const { getCache, setCache } = require('../utils/cache');
const { log, warn } = require('../utils/logger');
const crypto       = require('crypto');

// In-memory store (replace with a real DB like PostgreSQL in production)
const fareStore = [];

// ── POST /api/fares/submit ───────────────────────────────────
// Called after user completes a ride and submits their fare
router.post('/fares/submit', async (req, res) => {
  const { pickup, dropoff, app, service, farePaid, currency, city, country } = req.body;

  if (!pickup?.lat || !dropoff?.lat || !app || !farePaid) {
    return res.status(400).json({ error: 'Missing required: pickup, dropoff, app, farePaid' });
  }

  const entry = {
    id:         crypto.randomUUID(),
    app:        app.toLowerCase(),
    service:    service || app,
    farePaid:   parseFloat(farePaid),
    currency:   currency || 'THB',
    city:       city || 'Unknown',
    country:    (country || 'TH').toUpperCase(),
    routeHash:  makeRouteHash(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng),
    pickupLat:  parseFloat(pickup.lat),
    pickupLng:  parseFloat(pickup.lng),
    dropoffLat: parseFloat(dropoff.lat),
    dropoffLng: parseFloat(dropoff.lng),
    submittedAt: new Date().toISOString(),
  };

  fareStore.push(entry);

  // Invalidate the route cache so next request gets fresh data
  const cacheKey = `crowd:${entry.routeHash}:${app}`;
  await setCache(cacheKey, null, 1); // expire immediately

  log(`[Crowd] Fare submitted: ${app} ${currency}${farePaid} in ${city}`);
  res.json({ success: true, id: entry.id, message: 'Thank you! Your fare helps other riders.' });
});

// ── GET /api/fares/crowd ─────────────────────────────────────
// Returns crowdsourced fare stats for a route
router.get('/fares/crowd', async (req, res) => {
  const { pickupLat, pickupLng, dropLat, dropLng } = req.query;

  if (!pickupLat || !pickupLng || !dropLat || !dropLng) {
    return res.status(400).json({ error: 'Missing query params: pickupLat, pickupLng, dropLat, dropLng' });
  }

  const routeHash = makeRouteHash(pickupLat, pickupLng, dropLat, dropLng);
  const cacheKey  = `crowd:stats:${routeHash}`;

  const cached = await getCache(cacheKey);
  if (cached) return res.json(cached);

  // Get all submissions for this route in last 30 days
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = fareStore.filter(e =>
    e.routeHash === routeHash &&
    new Date(e.submittedAt).getTime() > thirtyDaysAgo
  );

  if (recent.length === 0) {
    return res.json({ hasData: false, entries: [] });
  }

  // Group by app and compute stats
  const byApp = {};
  for (const entry of recent) {
    if (!byApp[entry.app]) byApp[entry.app] = [];
    byApp[entry.app].push(entry.farePaid);
  }

  const stats = Object.entries(byApp)
    .filter(([, fares]) => fares.length >= 2) // need at least 2 data points
    .map(([app, fares]) => {
      const sorted = fares.sort((a, b) => a - b);
      return {
        app,
        low:     Math.round(percentile(sorted, 10)),
        high:    Math.round(percentile(sorted, 90)),
        median:  Math.round(percentile(sorted, 50)),
        count:   fares.length,
        source:  'crowdsourced',
        currency: recent.find(e => e.app === app)?.currency || 'THB',
      };
    });

  const result = { hasData: true, stats, totalSubmissions: recent.length };
  await setCache(cacheKey, result, 3600); // cache for 1 hour

  log(`[Crowd] Returning stats: ${stats.length} apps, ${recent.length} submissions`);
  res.json(result);
});

// ── Percentile calculator ─────────────────────────────────────
function percentile(sorted, p) {
  const idx = (p / 100) * (sorted.length - 1);
  const lo  = Math.floor(idx);
  const hi  = Math.ceil(idx);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

// ── Route hash — groups nearby pickup/dropoff into same bucket ─
// Uses 3 decimal places (~111m grid)
function makeRouteHash(pLat, pLng, dLat, dLng) {
  const key = `${parseFloat(pLat).toFixed(3)},${parseFloat(pLng).toFixed(3)}:${parseFloat(dLat).toFixed(3)},${parseFloat(dLng).toFixed(3)}`;
  return crypto.createHash('md5').update(key).digest('hex').slice(0, 12);
}

module.exports = router;
