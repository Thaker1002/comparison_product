// ============================================================
//  TEST SCRIPT — run with: node test/testFares.js
//  Tests formula engine directly (no server needed)
// ============================================================
const { calcAllFares }  = require('../formula/calculator');
const { getRoute }      = require('../utils/googleMaps');

async function runTests() {
  console.log('\n=== FARE ENGINE TEST ===\n');

  // ── Test 1: Bangkok formula ──────────────────────────────
  console.log('TEST 1: Bangkok formula (8.3km, 23min)');
  const bkkFares = calcAllFares(8.3, 23, 'TH', 'Bangkok');
  bkkFares.forEach(f => {
    console.log(`  ${f.app.padEnd(10)} ${f.service.padEnd(20)} ${f.currency} ${f.low}–${f.high}`);
  });

  // ── Test 2: Singapore formula ────────────────────────────
  console.log('\nTEST 2: Singapore formula (5.2km, 18min)');
  const sgFares = calcAllFares(5.2, 18, 'SG', 'Singapore');
  sgFares.forEach(f => {
    console.log(`  ${f.app.padEnd(10)} ${f.service.padEnd(20)} ${f.currency} ${f.low}–${f.high}`);
  });

  // ── Test 3: Dubai formula ────────────────────────────────
  console.log('\nTEST 3: Dubai formula (12.0km, 20min)');
  const dubaiFares = calcAllFares(12.0, 20, 'AE', 'Dubai');
  dubaiFares.forEach(f => {
    console.log(`  ${f.app.padEnd(10)} ${f.service.padEnd(20)} ${f.currency} ${f.low}–${f.high}`);
  });

  // ── Test 4: Haversine route (no Google key) ──────────────
  console.log('\nTEST 4: Route calculation (Haversine fallback)');
  // Bangkok: Selitxet → Park Plaza Sukhumvit 18
  const route = await getRoute(13.7200, 100.5147, 13.7400, 100.5300);
  console.log(`  Distance: ${route.distanceKm}km  Duration: ${route.durationMin}min  Source: ${route.source}`);

  console.log('\n=== ALL TESTS PASSED ===\n');
}

runTests().catch(console.error);
