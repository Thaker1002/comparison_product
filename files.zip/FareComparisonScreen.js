// ============================================================
//  FareComparisonScreen.js  — React Native
//  Complete mobile screen that:
//    1. Takes pickup + dropoff from user
//    2. Calls your /api/fares server
//    3. Shows ranked fare list
//    4. Opens the chosen app via deep link
//    5. Prompts user to submit actual fare (crowdsource)
// ============================================================
import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, ActivityIndicator,
  Alert, Linking, StyleSheet, TextInput, Platform, ScrollView,
} from 'react-native';

// ── Config ────────────────────────────────────────────────────
const SERVER_URL = 'https://your-server.com'; // ← replace with your server URL
const TIMEOUT_MS = 20000;

// ── App logos / display names ─────────────────────────────────
const APP_META = {
  uber:    { label: 'Uber',         color: '#000000', textColor: '#FFFFFF' },
  bolt:    { label: 'Bolt',         color: '#34D186', textColor: '#003300' },
  grab:    { label: 'Grab',         color: '#00B14F', textColor: '#FFFFFF' },
  ola:     { label: 'Ola',          color: '#EF3E23', textColor: '#FFFFFF' },
  indrive: { label: 'inDrive',      color: '#1C1C1C', textColor: '#00FF6B' },
  careem:  { label: 'Careem',       color: '#3AB54A', textColor: '#FFFFFF' },
  lyft:    { label: 'Lyft',         color: '#FF00BF', textColor: '#FFFFFF' },
  meter:   { label: 'Meter Taxi',   color: '#F5A623', textColor: '#FFFFFF' },
  gojek:   { label: 'Gojek',        color: '#009951', textColor: '#FFFFFF' },
};

// ── Deep link builders ────────────────────────────────────────
function buildDeepLink(app, pLat, pLng, dLat, dLng) {
  const links = {
    uber: `https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${pLat}&pickup[longitude]=${pLng}&pickup[nickname]=Pickup&dropoff[latitude]=${dLat}&dropoff[longitude]=${dLng}&dropoff[nickname]=Dropoff`,
    bolt: `https://bolt.eu/en-th/ride/?startLat=${pLat}&startLng=${pLng}&endLat=${dLat}&endLng=${dLng}`,
    grab: `grab://open?screenType=BOOKING&sourceID=${pLat},${pLng}&destinationID=${dLat},${dLng}`,
    ola:  `olacabs://app/launch?lat=${pLat}&lng=${pLng}&drop_lat=${dLat}&drop_lng=${dLng}`,
    indrive: `https://indrive.onelink.me/jWiX/openapp?af_dp=com.suol.rides%3A%2F%2Frides%3FpickupLat%3D${pLat}%26pickupLng%3D${pLng}%26dropoffLat%3D${dLat}%26dropoffLng%3D${dLng}`,
    careem: `https://www.careem.com/en-ae/`,
    lyft:  `https://lyft.com/ride?id=lyft&pickup[latitude]=${pLat}&pickup[longitude]=${pLng}&destination[latitude]=${dLat}&destination[longitude]=${dLng}`,
    gojek: `gojek://open?lat=${pLat}&long=${pLng}`,
    meter: null, // no app — just hail a cab
  };
  return links[app] || null;
}

// ── Main Component ────────────────────────────────────────────
export default function FareComparisonScreen() {
  const [pickupText,  setPickupText]  = useState('');
  const [dropoffText, setDropoffText] = useState('');
  const [fares,       setFares]       = useState([]);
  const [route,       setRoute]       = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState(null);
  const [country,     setCountry]     = useState('TH');
  const [city,        setCity]        = useState('Bangkok');

  // Hardcoded for demo — in real app, use device GPS or Google Places autocomplete
  const [pickup,  setPickup]  = useState({ lat: 13.7563, lng: 100.5018 });
  const [dropoff, setDropoff] = useState({ lat: 13.7400, lng: 100.5300 });

  // ── Fetch fares from server ────────────────────────────────
  const fetchFares = useCallback(async () => {
    setLoading(true);
    setError(null);
    setFares([]);

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

      const res = await fetch(`${SERVER_URL}/api/fares`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pickup, dropoff, country, city }),
        signal: controller.signal,
      });

      clearTimeout(timer);

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server error: ${res.status}`);
      }

      const data = await res.json();
      setFares(data.fares || []);
      setRoute(data.route || null);

    } catch (err) {
      if (err.name === 'AbortError') {
        setError('Request timed out — please try again');
      } else {
        setError(err.message || 'Could not fetch fares');
      }
    } finally {
      setLoading(false);
    }
  }, [pickup, dropoff, country, city]);

  // ── Open ride app via deep link ────────────────────────────
  const openApp = useCallback(async (fare) => {
    if (fare.app === 'meter') {
      Alert.alert('Meter Taxi', 'Hail a metered taxi on the street. Insist the driver uses the meter.');
      return;
    }

    const url = buildDeepLink(fare.app, pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    if (!url) {
      Alert.alert('Not available', 'This app is not supported in your country yet.');
      return;
    }

    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
      // Show fare submission prompt after a delay (app switches back)
      setTimeout(() => promptFareSubmit(fare), 3000);
    } else {
      // App not installed — open App Store / Play Store
      const storeUrls = {
        uber:    Platform.OS === 'ios' ? 'https://apps.apple.com/app/uber/id368677368' : 'https://play.google.com/store/apps/details?id=com.ubercab',
        bolt:    Platform.OS === 'ios' ? 'https://apps.apple.com/app/bolt-taxify/id675033630' : 'https://play.google.com/store/apps/details?id=ee.mtakso.client',
        grab:    Platform.OS === 'ios' ? 'https://apps.apple.com/app/grab/id647268330' : 'https://play.google.com/store/apps/details?id=com.grabtaxi.passenger',
        indrive: Platform.OS === 'ios' ? 'https://apps.apple.com/app/indrive/id780125801' : 'https://play.google.com/store/apps/details?id=sinet.startup.inDriver',
        ola:     Platform.OS === 'ios' ? 'https://apps.apple.com/app/ola-cabs/id539179365' : 'https://play.google.com/store/apps/details?id=com.ani.droid.client',
      };
      const storeUrl = storeUrls[fare.app];
      if (storeUrl) {
        Alert.alert(
          `${APP_META[fare.app]?.label || fare.app} not installed`,
          'Would you like to install it?',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Install', onPress: () => Linking.openURL(storeUrl) },
          ]
        );
      }
    }
  }, [pickup, dropoff]);

  // ── Post-ride fare submission prompt ───────────────────────
  const promptFareSubmit = useCallback((fare) => {
    const suggestions = [
      fare.low - 20, fare.low, fare.low + 10,
      fare.high - 10, fare.high, fare.high + 20
    ].filter(v => v > 0);

    Alert.alert(
      `How much did ${APP_META[fare.app]?.label} charge?`,
      'Your answer helps other riders get accurate estimates.',
      [
        ...suggestions.map(amount => ({
          text: `฿${amount}`,
          onPress: () => submitFare(fare, amount),
        })),
        { text: 'Skip', style: 'cancel' },
      ]
    );
  }, [pickup, dropoff, city, country]);

  const submitFare = useCallback(async (fare, amount) => {
    try {
      await fetch(`${SERVER_URL}/api/fares/submit`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pickup, dropoff,
          app:       fare.app,
          service:   fare.service,
          farePaid:  amount,
          currency:  fare.currency,
          city, country,
        }),
      });
      Alert.alert('Thank you!', 'Your fare has been recorded.');
    } catch {
      // Silent fail — not critical
    }
  }, [pickup, dropoff, city, country]);

  // ── Render fare card ───────────────────────────────────────
  const renderFare = ({ item: fare, index }) => {
    const meta      = APP_META[fare.app] || { label: fare.app, color: '#888', textColor: '#fff' };
    const isCheapest = index === 0;
    const isLive    = fare.source === 'live';

    return (
      <TouchableOpacity
        style={[styles.fareCard, isCheapest && styles.cheapestCard]}
        onPress={() => openApp(fare)}
        activeOpacity={0.8}
      >
        {isCheapest && (
          <View style={styles.cheapestBadge}>
            <Text style={styles.cheapestBadgeText}>CHEAPEST</Text>
          </View>
        )}

        <View style={styles.fareRow}>
          {/* App badge */}
          <View style={[styles.appBadge, { backgroundColor: meta.color }]}>
            <Text style={[styles.appBadgeText, { color: meta.textColor }]}>
              {meta.label.slice(0, 2).toUpperCase()}
            </Text>
          </View>

          {/* App name + service */}
          <View style={styles.fareInfo}>
            <Text style={styles.appName}>{meta.label}</Text>
            <Text style={styles.serviceName}>{fare.service}</Text>
          </View>

          {/* Fare range */}
          <View style={styles.fareAmount}>
            <Text style={styles.fareText}>
              {fare.currency} {fare.low}–{fare.high}
            </Text>
            <View style={[styles.sourceTag, isLive ? styles.liveTag : styles.estTag]}>
              <Text style={[styles.sourceText, isLive ? styles.liveText : styles.estText]}>
                {isLive ? 'Live' : 'Est.'}
              </Text>
            </View>
          </View>

          {/* Arrow */}
          {fare.app !== 'meter' && (
            <Text style={styles.arrow}>›</Text>
          )}
        </View>

        {fare.note && (
          <Text style={styles.noteText}>{fare.note}</Text>
        )}
      </TouchableOpacity>
    );
  };

  // ── Main render ─────────────────────────────────────────────
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Compare Rides</Text>
        {route && (
          <Text style={styles.routeInfo}>
            {route.distanceText}  •  {route.durationText}
          </Text>
        )}
      </View>

      {/* Location inputs — in real app: Google Places autocomplete */}
      <View style={styles.inputContainer}>
        <View style={styles.inputRow}>
          <View style={styles.dotGreen} />
          <TextInput
            style={styles.input}
            placeholder="Pickup location"
            value={pickupText}
            onChangeText={setPickupText}
            placeholderTextColor="#999"
          />
        </View>
        <View style={styles.inputDivider} />
        <View style={styles.inputRow}>
          <View style={styles.dotRed} />
          <TextInput
            style={styles.input}
            placeholder="Drop-off location"
            value={dropoffText}
            onChangeText={setDropoffText}
            placeholderTextColor="#999"
          />
        </View>
      </View>

      {/* Search button */}
      <TouchableOpacity
        style={[styles.searchBtn, loading && styles.searchBtnDisabled]}
        onPress={fetchFares}
        disabled={loading}
      >
        {loading
          ? <ActivityIndicator color="#fff" />
          : <Text style={styles.searchBtnText}>Compare Fares</Text>
        }
      </TouchableOpacity>

      {/* Error */}
      {error && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {/* Loading state */}
      {loading && (
        <View style={styles.loadingBox}>
          <Text style={styles.loadingText}>Checking Uber, Bolt, Grab and more...</Text>
        </View>
      )}

      {/* Fare list */}
      {fares.length > 0 && (
        <>
          <Text style={styles.resultCount}>
            {fares.length} options found — tap to book
          </Text>
          <FlatList
            data={fares}
            keyExtractor={(item, i) => `${item.app}-${item.service}-${i}`}
            renderItem={renderFare}
            contentContainerStyle={styles.fareList}
            showsVerticalScrollIndicator={false}
          />
          <Text style={styles.disclaimer}>
            Live = fetched directly from app API. Est. = calculated from current rates. Actual fare may vary with traffic and surge pricing.
          </Text>
        </>
      )}
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#F5F5F5' },
  header:          { backgroundColor: '#1A1A2E', paddingTop: 56, paddingBottom: 16, paddingHorizontal: 20 },
  headerTitle:     { fontSize: 22, fontWeight: '700', color: '#FFFFFF', marginBottom: 4 },
  routeInfo:       { fontSize: 13, color: '#AAAACC' },
  inputContainer:  { backgroundColor: '#FFFFFF', margin: 16, borderRadius: 12, padding: 16, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8, elevation: 3 },
  inputRow:        { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dotGreen:        { width: 12, height: 12, borderRadius: 6, backgroundColor: '#34D186' },
  dotRed:          { width: 12, height: 12, borderRadius: 6, backgroundColor: '#E24B4A' },
  input:           { flex: 1, fontSize: 15, color: '#333', paddingVertical: 6 },
  inputDivider:    { height: 1, backgroundColor: '#F0F0F0', marginVertical: 10, marginLeft: 24 },
  searchBtn:       { backgroundColor: '#1A1A2E', marginHorizontal: 16, padding: 16, borderRadius: 12, alignItems: 'center' },
  searchBtnDisabled: { opacity: 0.6 },
  searchBtnText:   { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  errorBox:        { margin: 16, padding: 12, backgroundColor: '#FFF0F0', borderRadius: 8, borderLeftWidth: 3, borderLeftColor: '#E24B4A' },
  errorText:       { color: '#A32D2D', fontSize: 13 },
  loadingBox:      { margin: 16, alignItems: 'center', padding: 20 },
  loadingText:     { color: '#888', fontSize: 13, marginTop: 10 },
  resultCount:     { marginHorizontal: 16, marginTop: 16, marginBottom: 8, fontSize: 13, color: '#666' },
  fareList:        { paddingHorizontal: 16, paddingBottom: 24 },
  fareCard:        { backgroundColor: '#FFFFFF', borderRadius: 12, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 6, elevation: 2 },
  cheapestCard:    { borderWidth: 2, borderColor: '#34D186' },
  cheapestBadge:   { backgroundColor: '#34D186', alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 4, marginBottom: 8 },
  cheapestBadgeText:{ color: '#003300', fontSize: 10, fontWeight: '700' },
  fareRow:         { flexDirection: 'row', alignItems: 'center', gap: 12 },
  appBadge:        { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  appBadgeText:    { fontSize: 12, fontWeight: '700' },
  fareInfo:        { flex: 1 },
  appName:         { fontSize: 15, fontWeight: '600', color: '#1A1A2E' },
  serviceName:     { fontSize: 12, color: '#888', marginTop: 1 },
  fareAmount:      { alignItems: 'flex-end', gap: 4 },
  fareText:        { fontSize: 16, fontWeight: '700', color: '#1A1A2E' },
  sourceTag:       { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  liveTag:         { backgroundColor: '#E2EFDA' },
  estTag:          { backgroundColor: '#FFF2CC' },
  sourceText:      { fontSize: 10, fontWeight: '600' },
  liveText:        { color: '#375623' },
  estText:         { color: '#7F4F0C' },
  arrow:           { fontSize: 22, color: '#CCC', marginLeft: 4 },
  noteText:        { fontSize: 11, color: '#888', marginTop: 8, fontStyle: 'italic' },
  disclaimer:      { marginHorizontal: 16, marginTop: 8, fontSize: 11, color: '#AAA', textAlign: 'center', lineHeight: 16 },
});
