// ============================================================
//  HEALTH + MONITORING ROUTES
//  GET /health           — basic liveness check
//  GET /health/scrapers  — test each scraper is responsive
//  GET /health/formula   — verify formula engine returns data
// ============================================================
const express          = require('express');
const router           = express.Router();
const { calcAllFares } = require('../formula/calculator');
const { getRoute }     = require('../utils/googleMaps');
const { log }          = require('../utils/logger');

const startTime = Date.now();

// ── GET /health ───────────────────────────────────────────────
router.get('/health', (req, res) => {
  res.json({
    status:    'ok',
    uptime:    Math.round((Date.now() - startTime) / 1000),
    timestamp:  new Date().toISOString(),
    node:       process.version,
    memory:     formatMemory(process.memoryUsage()),
  });
});

// ── GET /health/formula ───────────────────────────────────────
// Quick smoke test of the formula engine
router.get('/health/formula', async (req, res) => {
  try {
    const fares = calcAllFares(8.3, 23, 'TH', 'Bangkok');
    if (!fares || fares.length === 0) {
      return res.status(500).json({ status: 'error', message: 'Formula returned no fares' });
    }
    res.json({
      status:     'ok',
      fareCount:  fares.length,
      sample:     fares[0],
      message:    'Formula engine working correctly',
    });
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});

// ── GET /health/maps ──────────────────────────────────────────
// Test Google Maps / Haversine fallback
router.get('/health/maps', async (req, res) => {
  try {
    // Bangkok: Central World → Asok BTS
    const route = await getRoute(13.7466, 100.5393, 13.7363, 100.5600);
    res.json({
      status:  'ok',
      source:  route.source,
      result:  route,
      message: route.source === 'google' ? 'Google Maps API working' : 'Using Haversine fallback (no Google key)',
    });
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});

// ── GET /health/scrapers ──────────────────────────────────────
// Reports scraper status without actually running them
// (running scrapers as health check would be too slow/expensive)
router.get('/health/scrapers', (req, res) => {
  const hasProxy       = !!process.env.PROXY_URL;
  const hasGoogleKey   = !!process.env.GOOGLE_MAPS_KEY;
  const scraperTimeout = parseInt(process.env.SCRAPER_TIMEOUT_MS) || 18000;

  res.json({
    status: 'ok',
    config: {
      hasProxy,
      hasGoogleMapsKey:  hasGoogleKey,
      scraperTimeoutMs:  scraperTimeout,
      headless:          process.env.SCRAPER_HEADLESS !== 'false',
      proxyConfigured:   hasProxy ? 'yes' : 'no — bot detection risk',
    },
    scrapers: {
      uber: { configured: true,  note: 'Intercepts api.uber.com/v1.2/estimates/price' },
      bolt: { configured: true,  note: 'Intercepts node.bolt.eu/booking/v1/price' },
      ola:  { configured: true,  note: 'Intercepts book.olacabs.com/v1/products (India only)' },
      grab: { configured: false, note: 'No public web page — formula only' },
    },
    warnings: [
      !hasProxy      ? 'No proxy configured — scrapers may be blocked by Uber/Bolt bot detection' : null,
      !hasGoogleKey  ? 'No Google Maps key — using Haversine (less accurate distances)' : null,
    ].filter(Boolean),
  });
});

function formatMemory(mem) {
  const mb = (bytes) => `${Math.round(bytes / 1024 / 1024)}MB`;
  return { rss: mb(mem.rss), heapUsed: mb(mem.heapUsed), heapTotal: mb(mem.heapTotal) };
}

module.exports = router;
