// ── Simple timestamped logger ─────────────────────────────────
const ts = () => new Date().toISOString().slice(11, 23); // HH:MM:SS.mmm

const log  = (msg) => console.log(`[${ts()}] INFO  ${msg}`);
const warn = (msg) => console.warn(`[${ts()}] WARN  ${msg}`);
const err  = (msg) => console.error(`[${ts()}] ERROR ${msg}`);

module.exports = { log, warn, err };
